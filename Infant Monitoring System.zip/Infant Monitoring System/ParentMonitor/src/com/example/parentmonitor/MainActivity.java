package com.example.parentmonitor;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.net.URLConnection;

import LibPack.ValuesDB;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends Activity {

	ImageView iv;
	LongOperation lo;
	Handler h;
	Runnable r;
	ToggleButton b1;
	Boolean flag=false;
	ValuesDB vdbrec;
	TextView t1,t2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		iv = (ImageView) findViewById(R.id.imageView1);
		b1=(ToggleButton) findViewById(R.id.toggleButton1);
		t1=(TextView) findViewById(R.id.Txtval1);
		t2=(TextView) findViewById(R.id.Txtval2);

		h = new Handler(Looper.getMainLooper());
		h.post(r = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if(!flag){
				lo = new LongOperation();
				lo.execute("");
				}
				h.postAtTime(this, SystemClock.uptimeMillis() + 20);
			}
		});
	b1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
		
		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			// TODO Auto-generated method stub
			if(isChecked){
				flag=false;
			}else{
				flag=true;
			}
		}
	});
	}

	public void setimageView() {

		Bitmap myBmp = Bitmap.createBitmap(vdbrec.mRGBData,
				vdbrec.mActualImageWidth, vdbrec.mActualImageHeight,
				Bitmap.Config.RGB_565);
		iv.setImageBitmap(myBmp);
		iv.invalidate();

	}

	public class LongOperation extends AsyncTask<String, Void, String> {

		@Override
		protected void onPreExecute() {
			vdbrec = new ValuesDB();
			super.onPreExecute();
		}

		@Override
		protected String doInBackground(String... params) {
			try {

				String urlstr = "http://" + CommonData.IP
						+ ":8080/CityCentralServer/ReadVideo";
				URL url = new URL(urlstr);
				URLConnection connection = url.openConnection();

				connection.setDoOutput(true);
				connection.setDoInput(true);

				// don't use a cached version of URL connection
				connection.setUseCaches(false);
				connection.setDefaultUseCaches(false);
				connection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");

				// specify the content type that binary data is sent
				connection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");

				// define a new ObjectInputStream on the input stream
				ObjectInputStream in = new ObjectInputStream(
						connection.getInputStream());
				// receive and deserialize the object, note the cast

				vdbrec = (ValuesDB) in.readObject();

				in.close();

			} catch (Exception e) {
				System.out.println("Error:" + e);
			}

			return null;

		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (vdbrec != null) {
				t1.setText(""+vdbrec.adc[0]);
				t2.setText(""+vdbrec.adc[1]);
				System.out.println("*************adc1" + vdbrec.adc[0]);
				System.out.println("***************adc2" + vdbrec.adc[1]);
				// System.out.println("************th1"+vdbrec.thr[0]);
				// System.out.println("***************th2"+vdbrec.thr[1]);
				setimageView();
			} else {
				Toast.makeText(getApplicationContext(), "No Video Field", 5)
						.show();
			}

		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
