package com.example.OwletPack;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import LibPack.SingleUser;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {
	EditText user, pass;
	Button login;
	TextView signup;
	SingleUser su,respsu;
	String respfromdb="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		user = (EditText) findViewById(R.id.textUser);
		pass = (EditText) findViewById(R.id.textPass);
		login = (Button) findViewById(R.id.btnlogin);
		signup = (TextView) findViewById(R.id.signUplink);
		login.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				if (user.getText().toString().equals("") || pass.getText().toString().equals("")) {
					Toast.makeText(getApplicationContext(), "Username or Password Should not be empty", Toast.LENGTH_SHORT).show();
					return;
				}
				else{
					DoInBackground background = new DoInBackground();
					background.execute("");
					//finish();
				}
				
			}
		});
		
		signup.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent ii = new Intent(getApplicationContext(),
						SignUpActivity.class);
				startActivity(ii);
			}
		});
	}

	
	public class DoInBackground extends AsyncTask<String, Void, String> {
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			su = new SingleUser();
		}

		@Override
		protected String doInBackground(String... params) {
			su = new SingleUser();
			su.uid = user.getText().toString().trim();
			su.pass = pass.getText().toString().trim();
			SoapObject request = new SoapObject(CommonData.NAMESPACE, "Android_login");
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
					SoapEnvelope.VER11);
			PropertyInfo pi = new PropertyInfo();
			pi.setName("obj");
			pi.setValue(objectToString(su));
			pi.setType(String.class);
			request.addProperty(pi);
			envelope.setOutputSoapObject(request);

			HttpTransportSE androidHttpTransport = new HttpTransportSE(CommonData.URL);
System.out.println("URL IS:"+CommonData.URL);
			try {
				androidHttpTransport.call(CommonData.SOAP_ACTION, envelope);

				SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;

				String resp = resultsRequestSOAP
						.getPrimitivePropertyAsString("return");
				respfromdb=resp;
				
				System.out.println("********######result is resp:"+resp);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			
				if (respfromdb.equalsIgnoreCase("true")) {
					Toast.makeText(getApplicationContext(), "Login successful..!!", Toast.LENGTH_SHORT).show();
					Intent ii = new Intent(getApplicationContext(),
							MyBlueToothClientActivity.class);
					ii.putExtra("uid", su.uid);
					startActivity(ii);
				} else {
					Toast.makeText(getApplicationContext(), "Wrong Credentials..!!", Toast.LENGTH_SHORT).show();
				}
			
			
		}
	}

	Object stringToObject(String inp) {
		byte b[] = Base64.decode(inp);
		Object ret = null;
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(b);
			ObjectInput in = new ObjectInputStream(bis);
			ret = in.readObject();
			bis.close();
			in.close();
		} catch (Exception e) {
			System.out.println("NOT DE-SERIALIZABLE: " + e);
		}
		return ret;
	}

	String objectToString(Object obj) {
		byte[] b = null;
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutput out = new ObjectOutputStream(bos);
			out.writeObject(obj);
			b = bos.toByteArray();
		} catch (Exception e) {
			System.out.println("NOT SERIALIZABLE: " + e);
		}
		return Base64.encode(b);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

}
