package com.example.OwletPack;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import LibPack.SingleUser;
import android.R.color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class SignUpActivity extends Activity {
	RadioGroup rg;
	RadioButton male, female;
	private Button buttonCancel, btnSignup;
	private EditText uid, fname,mname,lname, pw, confirmPW, mbl, email, add;
	String Gender = "M";
	String valid_name = null, valid_email = null;
	SingleUser user;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sign_up);
		user=new SingleUser();
		fname = (EditText) findViewById(R.id.editFname);
		mname = (EditText) findViewById(R.id.editMname);
		lname = (EditText) findViewById(R.id.editLname);
		uid = (EditText) findViewById(R.id.edituserid);
		add = (EditText) findViewById(R.id.editAdress);
		pw = (EditText) findViewById(R.id.editPassWord);
		confirmPW = (EditText) findViewById(R.id.editConfirmPassword);
		mbl = (EditText) findViewById(R.id.editMobile);
		email = (EditText) findViewById(R.id.editEmail);
		buttonCancel = (Button) findViewById(R.id.btnCancel);
		male = (RadioButton) findViewById(R.id.radioM);
		female = (RadioButton) findViewById(R.id.radioF);
		rg = (RadioGroup) findViewById(R.id.radioGroup1);
		btnSignup = (Button) findViewById(R.id.buttonSignin);
		
		
		btnSignup.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				DoInBackground background = new DoInBackground();
				background.execute("");

			}
		});
		
		rg.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// find which radio button is selected
				if (checkedId == R.id.radioM) {
					Gender = "M";
					Toast.makeText(getApplicationContext(), "You Select male",
							Toast.LENGTH_SHORT).show();
				} else if (checkedId == R.id.radioF) {
					Gender = "F";
					Toast.makeText(getApplicationContext(),
							"You Select Female", Toast.LENGTH_SHORT).show();
				}
			}

		});
		
		buttonCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		
		
		
		
		mbl.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				isMobileNo(mbl);
			}
		});

		email.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				Is_Valid_Email(email);
			}
		});

		confirmPW.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				isPasswordequal(confirmPW);
			}
		});
		fname.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				Is_Valid_Person_Name(fname);
			}
		});
		mname.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				Is_Valid_Person_Name(mname);
			}
		});
		lname.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				Is_Valid_Person_Name(lname);
			}
		});
	}

	public class DoInBackground extends AsyncTask<String, Void, String> {
		String resp;

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			System.out.println("before Object INIT");
			user = new SingleUser();
			System.out.println("after Object INIT");
		}

		@Override
		protected String doInBackground(String... params) {
			System.out.println("Inside background....");

			user.uid = uid.getText().toString();
			user.fname = fname.getText().toString();
			user.mname = mname.getText().toString();
			user.lname = lname.getText().toString();
			user.city = add.getText().toString();
			user.mob = mbl.getText().toString();
			user.email = email.getText().toString();
			user.Gender = Gender;
			user.pass = pw.getText().toString();
			
			SoapObject request = new SoapObject(CommonData.NAMESPACE, "SignUp");
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
					SoapEnvelope.VER11);
			PropertyInfo pi = new PropertyInfo();
			pi.setName("obj");
			pi.setValue(objectToString(user));
			pi.setType(String.class);
			request.addProperty(pi);
			envelope.setOutputSoapObject(request);
			HttpTransportSE androidHttpTransport = new HttpTransportSE(CommonData.URL);
			try {
				androidHttpTransport.call(CommonData.SOAP_ACTION, envelope);
				SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;
				resp = resultsRequestSOAP
						.getPrimitivePropertyAsString("return");
				System.out.println("result#############################" + resp);

			} catch (Exception e) {
				e.printStackTrace();
			}
			return resp;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (resp.toString().equals("YES")) {
				Toast.makeText(getApplicationContext(),
						"User Created..Go for Login!!!!", Toast.LENGTH_SHORT)
						.show();
				Intent intent = new Intent(getApplicationContext(),
						LoginActivity.class);
				startActivity(intent);
			} else {
				Toast.makeText(getApplicationContext(),
						"ERROR in User creation..", Toast.LENGTH_SHORT).show();
			}

		}
	}

	
	public void Is_Valid_Person_Name(EditText edt) throws NumberFormatException {
		if (edt.getText().toString().length() <= 0) {
			edt.setError(Html.fromHtml("<font color='blue'>Accept Alphabets Only.</font>"));

			valid_name = null;
		} else if (!edt.getText().toString().matches("[a-zA-Z ]+")) {
			edt.setError(Html.fromHtml("<font color='blue'>Accept Alphabets Only.</font>"));

			valid_name = null;
		} else {
			valid_name = edt.getText().toString();
		}

	}

	// =========================================================================================================
	public void Is_Valid_Email(EditText edt) {
		if (edt.getText().toString() == null) {
			edt.setError(Html.fromHtml("<font color='blue'>Invalid Email Address.</font>"));
			valid_email = null;
		} else if (isEmailValid(edt.getText().toString()) == false) {
			edt.setError(Html.fromHtml("<font color='blue'>Invalid Email Address.</font>"));
			valid_email = null;
		} else {
			valid_email = edt.getText().toString();
		}
	}

	boolean isEmailValid(CharSequence email) {
		return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
	} // end of email matcher

	public boolean isMobileNo(EditText edt) {
		boolean flag = false;

		if ((edt.getText().toString().length()) == 10) {
			Toast.makeText(getApplicationContext(), "Correct!!!!",
					Toast.LENGTH_LONG).show();
			flag = true;
		} else {
			
			edt.setError(Html.fromHtml("<font color='blue'>Must be 10 digit!!!!</font>"));
		}

		return flag;
	}

	public boolean isPasswordequal(EditText ed) {
		boolean flag = false;

		if (ed.getText().toString().equals(pw.getText().toString())) {
			Toast.makeText(getApplicationContext(), "matched!!!!",
					Toast.LENGTH_LONG).show();
			flag = true;
		} else {
			ed.setError(Html.fromHtml("<font color='blue'>Confirm Password!!!!</font>"));
		}

		return flag;
	}

	Object stringToObject(String inp) {
		byte b[] = Base64.decode(inp);
		Object ret = null;
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(b);
			ObjectInput in = new ObjectInputStream(bis);
			ret = in.readObject();
			bis.close();
			in.close();
		} catch (Exception e) {
			System.out.println("NOT DE-SERIALIZABLE: " + e);
		}
		return ret;
	}

	String objectToString(Object obj) {
		byte[] b = null;
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutput out = new ObjectOutputStream(bos);
			out.writeObject(obj);
			b = bos.toByteArray();
		} catch (Exception e) {
			System.out.println("NOT SERIALIZABLE: " + e);
		}
		return Base64.encode(b);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.sign_up, menu);
		return true;
	}

}
