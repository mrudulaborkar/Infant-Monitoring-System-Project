package com.example.OwletPack;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.net.URLConnection;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import com.example.OwletPack.R;

import LibPack.Techniciondata;
import LibPack.ValuesDB;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

public class CommonData {
	public static final String NAMESPACE = "http://MyPack/";
	public static final String SOAP_ACTION = "CityServices";

	public static boolean cancel = false, running = false,
			sendToServer = false, sendvideo = false;
	public static ValuesDB vdb;
	public static Techniciondata tdb;
	public static boolean valueRequested = false;
	public static String error = null, urlstr = "", ip;
	public static BluetoothClientService mChatService = null;
	public static Context context = null;
	public static boolean sendCommand = false;
	public static int cmd = -1;
	public static String URL, dupEntry = "";
	public static String resp;
	public static String Hardware_Location = "";

	
	
	public static class LongOperation extends AsyncTask<String, Void, String> {
		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub
			while (!cancel) {
				// System.out.println("in cancel");
				while (running) {
					// System.out.println("in running");
					byte[] b = new byte[] { (byte) vdb.opcode,
							(byte) vdb.operand };
					System.out.println("opcode"+vdb.opcode+"  oprand:"+vdb.operand);
					sendMessage(b);
					valueRequested = true;
					if (vdb.opcode != 73) {
						vdb.opcode = 73;
						vdb.operand = vdb.currentChannel;
					}
					try {
						Thread.sleep(100);
					} catch (Exception e) {
						System.out.println("Error in long Operation : " + e);
					}
					if (sendToServer) {
						// System.out.println("in long operation");
						sendToServer = false;
						String METHOD_NAME = "updateDeviceData";
						SoapObject request = new SoapObject(
								CommonData.NAMESPACE, METHOD_NAME);
						SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
								SoapEnvelope.VER11);
						PropertyInfo pi = new PropertyInfo();
						pi.setName("values");
						pi.setValue(objectToString(vdb));
						pi.setType(String.class);
						request.addProperty(pi);
						envelope.setOutputSoapObject(request);
						HttpTransportSE androidHttpTransport = new HttpTransportSE(
								CommonData.URL);
						try {
							androidHttpTransport.call(SOAP_ACTION, envelope);
							SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;
							resp = resultsRequestSOAP
									.getPrimitivePropertyAsString("return");
							if (resp.equals("Successful")) {
								// System.out.println("data Written succ.......");
							} else {
								// System.out.println("failed...");
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
			return null;
		}
	}


	
//	public static class LongOperation11 extends AsyncTask<String, Void, String> {
//
//		@Override
//		protected void onPreExecute() {
//		
//			super.onPreExecute();
//		}
//
//		@Override
//		protected String doInBackground(String... params) {
//			try {
//
//				String urlstr = "http://192.168.1.18:8080/CityCentralServer/WriteServlet";
//				URL url = new URL(urlstr);
//				URLConnection connection = url.openConnection();
//				System.out.println("in server1");
//
//				connection.setDoOutput(true);
//				connection.setDoInput(true);
//
//				// don't use a cached version of URL connection
//				connection.setUseCaches(false);
//				connection.setDefaultUseCaches(false);
//				connection.setRequestProperty("Content-Type",
//						"application/x-www-form-urlencoded");
//				System.out.println("in server2");
//				// specify the content type that binary data is sent
//				connection.setRequestProperty("Content-Type",
//						"application/x-www-form-urlencoded");
//				ObjectOutputStream out = new ObjectOutputStream(
//						connection.getOutputStream());
//				// send and serialize the object
//				out.writeObject(vdb);
//				out.close();
//				System.out.println("in server3");
//
//				// define a new ObjectInputStream on the input stream
//				ObjectInputStream in = new ObjectInputStream(
//						connection.getInputStream());
//				// receive and deserialize the object, note the cast
//
//				String resp = (String) in.readObject();
//				if(resp.equals("Successful")){
//					System.out.println("Writng success...");
//				}else{
//					System.out.println("Writng failed...");
//				}
//				in.close();
//
//			} catch (Exception e) {
//				System.out.println("Error:" + e);
//			}
//				
//			return null;
//		}
//
//		
//	}

	public static void fetch_client_command() {
		error = null;
		//System.out.println("IN mETHOD*******************************");
		String METHOD_NAME = "updatevideofeed";
		SoapObject request = new SoapObject(CommonData.NAMESPACE, METHOD_NAME);
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		PropertyInfo pi = new PropertyInfo();
		pi.setName("values");
		pi.setValue(objectToString(vdb));
		pi.setType(String.class);
		request.addProperty(pi);
		envelope.setOutputSoapObject(request);
		HttpTransportSE androidHttpTransport = new HttpTransportSE(
				CommonData.URL);
		try { 
			androidHttpTransport.call(SOAP_ACTION, envelope);
			SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;
			resp = resultsRequestSOAP.getPrimitivePropertyAsString("return");
			if (resp.equals("Successful")) {
				// System.out.println("video data Written succ.......");
			} else {
				// System.out.println("video failed...");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String objectToString(Object obj) {
		byte[] b = null;
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutput out = new ObjectOutputStream(bos);
			out.writeObject(obj);
			b = bos.toByteArray();
		} catch (Exception e) {
			System.out.println("NOT SERIALIZABLE: " + e);
		}
		return Base64.encode(b);
	}

	public static Object stringToObject(String inp) {
		byte b[] = Base64.decode(inp);
		Object ret = null;
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(b);
			ObjectInput in = new ObjectInputStream(bis);
			ret = in.readObject();
			bis.close();
			in.close();
		} catch (Exception e) {
			System.out.println("NOT DE-SERIALIZABLE: " + e);
		}
		return ret;
	}

	public static void sendMessage(byte[] send) {
		// Check that we're actually connected before trying anything
		if (mChatService.getState() != BluetoothClientService.STATE_CONNECTED) {
			Toast.makeText(context, R.string.not_connected, Toast.LENGTH_SHORT)
					.show();
			return;
		}

		// Check that there's actually something to send
		if (send.length > 0) {
			// Get the message bytes and tell the BluetoothChatService to write
			mChatService.write(send);
		}
	}

}
