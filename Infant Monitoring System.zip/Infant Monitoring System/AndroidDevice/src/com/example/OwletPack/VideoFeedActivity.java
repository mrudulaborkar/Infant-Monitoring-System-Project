package com.example.OwletPack;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.Calendar;
import java.util.Locale;
import java.util.StringTokenizer;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import com.example.OwletPack.R;

import LibPack.FeatureData;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.CheckBox;
import android.widget.Toast;

public class VideoFeedActivity extends Activity implements
		TextureView.SurfaceTextureListener, OnInitListener {

	private Camera mCamera;
	private TextureView mTextureView;
	private DrawOnTop mDrawOnTop;
	public static int corrX1;
	public static int corrY1;
	public static int WW, HH;
	public static int WW_SCR, HH_SCR;
	int sumR, sumG, sumB;
	public int MAX_DIFF = 3000;

	public FeatureData fd_objects;

	public double curr_features_fast[][];
	public double curr_features_normalized[][];

	public int objIndex;
	public int sampleIndex;
	public int histIndex;

	public int eucDetectedIndex;
	public double eucError;
	public long eucTrainTime;
	public long eucTestTime;

	public int tempRGBData[];
	public int binaryPixData[][];

	public int showStatusLimit;
	public String showStatus;

	public String strCurr_H;
	public boolean showDetails;
	public String strDetails;
	boolean mFinished;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		CommonData.sendvideo=true;
		mTextureView = new TextureView(this);
		mTextureView.setSurfaceTextureListener(this);
		mFinished = false;

		fd_objects = new FeatureData();

		WW_SCR = getApplicationContext().getResources().getDisplayMetrics().widthPixels;
		HH_SCR = getApplicationContext().getResources().getDisplayMetrics().heightPixels;

		strCurr_H = "";
		strDetails = "";

		tempRGBData = new int[240 * 320];
		binaryPixData = new int[240][320];

		// initialization
		curr_features_fast = new double[2][32];
		curr_features_normalized = new double[2][32];

		// resetCurrentFeatures();
		showDetails = false;

		// Create our Preview view and set it as the content of our activity.
		// Create our DrawOnTop view.
		mDrawOnTop = new DrawOnTop(this, this);

		setContentView(mTextureView);
		addContentView(mDrawOnTop, new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT));
		View child1 = LayoutInflater.from(this).inflate(R.layout.recog_menu,
				null);
		addContentView(child1, new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT));
		
	}

	public void onSurfaceTextureAvailable(SurfaceTexture surface, int width,
			int height) {
		mCamera = Camera.open();

		try {
			mCamera.setPreviewTexture(surface);
			Camera.Parameters parameters = mCamera.getParameters();
			parameters.setPreviewSize(320, 240);
			mCamera.setParameters(parameters);
			mCamera.startPreview();
			mCamera.setPreviewCallback(new Camera.PreviewCallback() {

				@Override
				public void onPreviewFrame(byte[] data, Camera camera) {
					if ((mDrawOnTop == null) || mFinished)
						return;

					if (mDrawOnTop.mBitmap == null) {
						// Initialize the draw-on-top companion
						Camera.Parameters params = camera.getParameters();
						mDrawOnTop.mActualImageWidth = params.getPreviewSize().width;
						mDrawOnTop.mActualImageHeight = params.getPreviewSize().height;

						mDrawOnTop.mBitmap = Bitmap.createBitmap(
								mDrawOnTop.mActualImageWidth,
								mDrawOnTop.mActualImageHeight,
								Bitmap.Config.RGB_565);

						mDrawOnTop.mRGBData = new int[mDrawOnTop.mActualImageWidth
								* mDrawOnTop.mActualImageHeight];
						mDrawOnTop.pixels = new int[mDrawOnTop.mActualImageWidth
								* mDrawOnTop.mActualImageHeight];
						mDrawOnTop.mYUVData = new byte[data.length];

						// System.out.println("MY DATA LENGTH :" + data.length);
					}

					// Pass YUV data to draw-on-top companion
					System.arraycopy(data, 0, mDrawOnTop.mYUVData, 0,
							data.length);
					mDrawOnTop.invalidate();
				}
			});
		} catch (IOException ioe) {
			// Something bad happened
		}
	}

	public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width,
			int height) {
		// Ignored, Camera does all the work for us
	}

	public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
		try {
			mCamera.setPreviewCallback(null);
			mCamera.stopPreview();

		} catch (Exception e) {
		}
		try {
			mCamera.release();
		} catch (Exception e) {
		}
		return true;
	}

	public void onSurfaceTextureUpdated(SurfaceTexture surface) {
		// Invoked every time there's a new Camera preview frame

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onInit(int status) {
		// TODO Auto-generated method stub

	}

}

class DrawOnTop extends View {
	Bitmap mBitmap;
	Paint mPaintBlack;
	Paint mPaintYellow;
	Paint mPaintRed;
	Paint mPaintGreen;
	Paint mPaintBlue;
	byte[] mYUVData;
	public static int[] mRGBData;
	int[] pixels;
	int mActualImageWidth, mActualImageHeight;

	public static int x1, y1, init1;
	public static int sumX1, sumY1;
	public static VideoFeedActivity parent;
	public String resp = "";
	Context context;
	static int col;
	Canvas locCanvas;
	Rect src, dst;

	public static int sumR, sumG, sumB;
	int currentMotion = 0, sensitivity = 40, currentMotionThreshold = 20;

	public DrawOnTop(Context context, VideoFeedActivity parent) {
		super(context);
		this.parent = parent;
		locCanvas = new Canvas();

		mPaintBlack = new Paint();
		mPaintBlack.setStyle(Paint.Style.FILL);
		mPaintBlack.setColor(Color.WHITE);
		mPaintBlack.setTextSize(25);
		context = parent;

		mBitmap = null;
		mYUVData = null;
		mRGBData = null;
		pixels = null;
		init1 = 0;
		src = dst = null;

	}

	@Override
	protected void onDraw(Canvas canvas) {
		// System.out.println("on draw");
		if (mBitmap != null) {

			locCanvas = canvas;
			int canvasWidth = canvas.getWidth();
			int canvasHeight = canvas.getHeight();

			VideoFeedActivity.WW = mActualImageWidth;
			VideoFeedActivity.HH = mActualImageHeight;
			CommonData.vdb.mActualImageWidth = mActualImageWidth;
			CommonData.vdb.mActualImageHeight = mActualImageHeight;
			// Convert from YUV to RGB
			mRGBData = convertYUV420_NV21toARGB8888(mYUVData,
					mActualImageWidth, mActualImageHeight);
			// Filling VDB Object
			CommonData.vdb.mRGBData = mRGBData;



			// Draw bitmap
			mBitmap.setPixels(mRGBData, 0, mActualImageWidth, 0, 0,
					mActualImageWidth, mActualImageHeight);
			if (src == null || dst == null) {
				src = new Rect(0, 0, mBitmap.getWidth(), mBitmap.getHeight());
				dst = new Rect(0, 0, canvasWidth, canvasHeight);
			}
			canvas.drawBitmap(mBitmap, src, dst, null);

			if (parent.showStatusLimit > 0) {
				parent.showStatusLimit--;
				canvas.drawText(parent.showStatus, 50, 75, mPaintBlack);
			}

			if (parent.showDetails) {
				canvas.drawText(parent.strCurr_H, 50, 275, mPaintBlack);
				canvas.drawText(parent.strDetails, 50, 325, mPaintBlack);
			}

		} // end if statement
		super.onDraw(canvas);
	} // end onDraw method

	public static int[] convertYUV420_NV21toARGB8888(byte[] data, int width,
			int height) {
		int size = width * height;
		int offset = size;
		int[] pixels = new int[size];
		int u, v, y1, y2, y3, y4;

		// i along Y and the final pixels
		// k along pixels U and V
		for (int i = 0, k = 0; i < size; i += 2, k += 2) {
			y1 = data[i] & 0xff;
			y2 = data[i + 1] & 0xff;
			y3 = data[width + i] & 0xff;
			y4 = data[width + i + 1] & 0xff;

			v = data[offset + k] & 0xff;
			u = data[offset + k + 1] & 0xff;
			v = v - 128;
			u = u - 128;

			pixels[i] = convertYUVtoARGB(y1, u, v);
			pixels[i + 1] = convertYUVtoARGB(y2, u, v);
			pixels[width + i] = convertYUVtoARGB(y3, u, v);
			pixels[width + i + 1] = convertYUVtoARGB(y4, u, v);

			if (i != 0 && (i + 2) % width == 0)
				i += width;
		}

		return pixels;
	}

	private static int convertYUVtoARGB(int y, int u, int v) {
		int r = y + (int) (1.772f * v);
		int g = y - (int) (0.344f * v + 0.714f * u);
		int b = y + (int) (1.402f * u);
		r = r > 255 ? 255 : r < 0 ? 0 : r;
		g = g > 255 ? 255 : g < 0 ? 0 : g;
		b = b > 255 ? 255 : b < 0 ? 0 : b;
		return 0xff000000 | (r << 16) | (g << 8) | b;
	}

	


}
