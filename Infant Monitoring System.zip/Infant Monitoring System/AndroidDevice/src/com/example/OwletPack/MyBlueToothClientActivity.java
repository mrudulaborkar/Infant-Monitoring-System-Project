package com.example.OwletPack;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import LibPack.ValuesDB;
import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Bitmap.Config;
import android.net.NetworkInfo.DetailedState;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.StrictMode;
import android.os.SystemClock;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

import com.example.OwletPack.R;
import com.example.OwletPack.CommonData.LongOperation;

public class MyBlueToothClientActivity extends Activity {
	// Debugging
	private static final String TAG = "BluetoothChat";
	private static final boolean D = true;
	CommonData.LongOperation lo;

	// Message types sent from the BluetoothChatService Handler
	public static final int MESSAGE_STATE_CHANGE = 1;
	public static final int MESSAGE_READ = 2;
	public static final int MESSAGE_WRITE = 3;
	public static final int MESSAGE_DEVICE_NAME = 4;
	public static final int MESSAGE_TOAST = 5;

	boolean once = false;

	// Key names received from the BluetoothChatService Handler
	public static final String DEVICE_NAME = "device_name";
	public static final String TOAST = "toast";

	// Intent request codes
	private static final int REQUEST_CONNECT_DEVICE_INSECURE = 2;
	private static final int REQUEST_ENABLE_BT = 3;
	public int onDeviceData = 0;

	// Layout Views
	private TextView mTitle;
	String contents,uid;

	Button start, stop, btnStop;

	ProgressBar[] pgAdc;
	String error;
	// for graph
	int x = 0;
	long diffTime = 0, currTime = 0, averageTime = 0;
	ArrayList<Long> peakTime;

	Bitmap b;
	Canvas c;
	Paint p;
	ImageView iv;

	double destLat, destLong;
	Context context;

	int tempcnt = 0, humcnt = 0, gascnt = 0, wtcnt = 0;
	TextView[] showValues;
	Spinner s0, s1;
	String S0val[], s1val[];
	int cnt1 = 0, cnt2 = 0, cnt3 = 0, cnt4 = 0, heartPulse = 1;;

	int count = 0;
	// Name of the connected device
	private String mConnectedDeviceName = null;
	// Array adapter for the conversation thread
	private ArrayAdapter<String> mConversationArrayAdapter;
	// String buffer for outgoing messages
	private StringBuffer mOutStringBuffer;
	// Local Bluetooth adapter
	private BluetoothAdapter mBluetoothAdapter = null;

	// Member object for the chat services
	Handler h;
	boolean deformationStatus = false;;
	TextView speedTv, txtheartpulse;
	Button feedButton;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		try {
			if (D)
				Log.e(TAG, "+++ ON CREATE +++");

			// Set up the window layout
			requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
			setContentView(R.layout.activity_my_blue_tooth_client);
			getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,
					R.layout.custom_title);
			if (Build.VERSION.SDK_INT >= 9) {
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
						.permitAll().build();
				StrictMode.setThreadPolicy(policy);
			}
			CommonData.vdb = new ValuesDB();
			Bundle extras = getIntent().getExtras();
			if (extras != null) {
				uid = extras.getString("uid");
				System.out.println("#####################:    "+uid);
			}


			// Set up the custom title
			mTitle = (TextView) findViewById(R.id.title_left_text);
			mTitle.setText(R.string.app_name);
			mTitle = (TextView) findViewById(R.id.title_right_text);

			context = this;

			showValues = new TextView[2];
			showValues[0] = (TextView) findViewById(R.id.valueView1);
			showValues[1] = (TextView) findViewById(R.id.valueView2);
			txtheartpulse = (TextView) findViewById(R.id.heartpulse);
			iv = (ImageView) findViewById(R.id.graphimage);
			pgAdc = new ProgressBar[2];
			pgAdc[0] = (ProgressBar) findViewById(R.id.pgSensor1);
			pgAdc[1] = (ProgressBar) findViewById(R.id.pgSensor2);

			s0 = (Spinner) findViewById(R.id.selectch);
			s1 = (Spinner) findViewById(R.id.selectth);

			peakTime = new ArrayList<Long>();
			CommonData.vdb.thr = new int[2];
			CommonData.vdb.adc = new int[2];
			CommonData.vdb.prevAdc = new int[2];
			CommonData.vdb.status = new String[2];
			CommonData.vdb.opcode = 0;
			CommonData.vdb.opData = 0;
			CommonData.vdb.operand = 0;
			S0val = new String[2];
			s1val = new String[255];

			for (int i = 0; i < 2; i++) {
				pgAdc[i].setMax(255);
				CommonData.vdb.thr[i] = 128;
				CommonData.vdb.adc[i] = 0;
				CommonData.vdb.prevAdc[i] = 0;
				CommonData.vdb.status[i] = "notallowed";
				int j = i + 1;
				S0val[i] = "" + j;
			}
			for (int i = 0; i < 255; i++) {
				s1val[i] = "" + i;
			}

			// For Graph

			b = Bitmap.createBitmap(300, 300, Config.ARGB_8888);
			c = new Canvas(b);
			p = new Paint();

			ArrayAdapter adapter = new ArrayAdapter(
					MyBlueToothClientActivity.this,
					android.R.layout.simple_spinner_item, S0val);
			adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			s0.setAdapter(adapter);
			ArrayAdapter adapter1 = new ArrayAdapter(
					MyBlueToothClientActivity.this,
					android.R.layout.simple_spinner_item, s1val);
			adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			s1.setAdapter(adapter1);
			s1.setSelection(128);

			feedButton = (Button) findViewById(R.id.feedButton);
			feedButton.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					// CommonData.vdb.Location=CommonData.Hardware_Location.toString();
					Intent ii = new Intent(getApplicationContext(),
							VideoFeedActivity.class);
					startActivity(ii);

				}
			});
			start = (Button) findViewById(R.id.btnStart);
			stop = (Button) findViewById(R.id.btnStop);

			btnStop = (Button) findViewById(R.id.buttonstop);

			btnStop.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					CommonData.sendvideo = false;

				}
			});

			mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

			// If the adapter is null, then Bluetooth is not supported
			if (mBluetoothAdapter == null) {
				Toast.makeText(this, "Bluetooth is not available",
						Toast.LENGTH_LONG).show();
				finish();
				return;
			}

			Intent serverIntent = new Intent(this, DeviceListActivity.class);
			startActivityForResult(serverIntent,
					REQUEST_CONNECT_DEVICE_INSECURE);

		} catch (Exception e) {
			// TODO: handle exception
			Toast.makeText(this, "onCreate() Ended : " + e.getMessage(),
					Toast.LENGTH_SHORT).show();
		}

		h = new Handler(Looper.getMainLooper());
		h.post(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				if (CommonData.sendvideo) {
					CommonData.fetch_client_command();
				}
				h.postAtTime(this, SystemClock.uptimeMillis());
			}
		});
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		// Stop the Bluetooth chat services
		if (CommonData.mChatService != null)
			CommonData.mChatService.stop();
		if (D)
			Log.e(TAG, "--- ON DESTROY ---");
	}

	@Override
	public void onStart() {
		super.onStart();
		// Toast.makeText(this, "onStart() Started", Toast.LENGTH_SHORT).show();
		if (D)
			Log.e(TAG, "++ ON START ++");

		// If BT is not on, request that it be enabled.
		// setupChat() will then be called during onActivityResult
		if (!mBluetoothAdapter.isEnabled()) {
			Intent enableIntent = new Intent(
					BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
			// Otherwise, setup the chat session
		} else {
			if (CommonData.mChatService == null)
				setupChat();
		}
		// Toast.makeText(this, "onStart() Ended", Toast.LENGTH_SHORT).show();
	}

	void paintBackground() {
		x = 0;
		p.setColor(Color.BLACK);
		c.drawRect(0, 0, 300, 200, p);
		p.setColor(Color.DKGRAY);

		for (int i = 0; i < 300; i += 5) {
			if (i % 50 == 0) {
				p.setStrokeWidth(3);
			} else {
				p.setStrokeWidth((int) 1);
			}
			c.drawLine(i, 0, i, 200, p);
		}
		for (int i = 0; i <= 200; i += 5) {
			if (i % 50 == 0) {
				p.setStrokeWidth(3);
			} else {
				p.setStrokeWidth((int) 1);
			}
			c.drawLine(0, i, 300, i, p);
		}

		p.setColor(Color.WHITE);
		p.setTextSize(15f);
		c.drawText("HEART BEAT GRAPH", 70, 100, p);

	}

	void paintHeartPulseECG() {
		// gd.channels[0][x / 3] = (byte) (adc[0] & 0xff);
		// gd.channels[1][x / 3] = (byte) (adc[1] & 0xff);
		// gd.channels[2][x / 3] = (byte) (adc[2] & 0xff);
		//
		// pgAdc.setProgress(adc[0]);
		// System.out.println("**heartbeat is: "+adc[1]);
		// temp = (int) (adc[0] * 0.48);
		// tempValue.setText("" + temp + " �C");
		// content = "";
		// content += "CURRENT TEMPERATURE : " + temp + " �C" + "\n";
		// content += "CURRENT HEART BEAT: " + heartPulse + "\n";
		//
		// gd.tempValue = temp;
		//
		//
		//
		// pgAdc1.setProgress(adc[2]);
		// level = (int) (adc[2]);
		// levelvalue.setText("" + level );
		// content = "";
		// content += "CURRENT LEVEL : " + level + " adc" + "\n";

		if (CommonData.vdb.adc[0] > 170) {
			peakTime.add(SystemClock.uptimeMillis());
		}

		int x1, y1, x2, y2;
		if (x > 0) {
			x1 = x - 3;
			x2 = x;
			y1 = ((255 - CommonData.vdb.prevAdc[0]) / 2) + 10;
			y2 = ((255 - CommonData.vdb.adc[0]) / 2) + 10;
			p.setStrokeWidth(2);
			p.setColor(Color.GREEN);
			c.drawLine(x1, y1, x2, y2, p);
			CommonData.vdb.prevAdc[0] = CommonData.vdb.adc[0];
			iv.setImageBitmap(b);
		}

		x += 2;
		if (x >= 300) {
			paintBackground();
			diffTime = 0;
			if (peakTime.size() > 0) {
				for (int i = 0; i < peakTime.size() - 1; i++) {
					diffTime += peakTime.get(i + 1) - peakTime.get(i);
				}
				averageTime = (long) diffTime / peakTime.size();
				if (averageTime > 0) {
					heartPulse = (int) (60000 / averageTime);
				}

				txtheartpulse.setText("HEART BEAT PULSE: " + heartPulse
						+ " bpm");
			}

			if (error != null) {
				Toast.makeText(getApplicationContext(), error,
						Toast.LENGTH_SHORT).show();
			}

			averageTime = 0;
			peakTime.clear();
			x = 0;
		}

	}

	private void setupChat() {
		Log.d(TAG, "setupChat()");
		CommonData.context = this;
		// Initialize the array adapter for the conversation thread
		mConversationArrayAdapter = new ArrayAdapter<String>(this,
				R.layout.message);
		start.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonData.valueRequested = false;
				CommonData.vdb.opcode = 73;
				CommonData.vdb.currentChannel = 0;
				CommonData.vdb.operand = CommonData.vdb.currentChannel;
				CommonData.running = true;
				lo = new LongOperation();
				lo.execute("");
				paintBackground();

			}
		});

		stop.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonData.vdb.opData = 0;
				CommonData.running = false;
				for (int i = 0; i < 2; i++) {
					pgAdc[i].setProgress(0);
					showValues[i].setText("");
				}
			}
		});
		s1.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				CommonData.vdb.thr[s0.getSelectedItemPosition()] = Integer
						.parseInt(s1.getSelectedItem().toString());

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				return;
			}
		});

		// Initialize the BluetoothChatService to perform bluetooth connections

		CommonData.mChatService = new BluetoothClientService(this, mHandler, 1);

		// Initialize the buffer for outgoing messages
		mOutStringBuffer = new StringBuffer("");
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		CommonData.cancel = true;
		super.onBackPressed();
	}



	// The Handler that gets information back from the BluetoothChatService
	private final Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MESSAGE_STATE_CHANGE:
				if (D)
					Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
				switch (msg.arg1) {
				case BluetoothClientService.STATE_CONNECTED:
					mTitle.setText(R.string.title_connected_to);
					mTitle.append(mConnectedDeviceName);
					mConversationArrayAdapter.clear();
					break;
				case BluetoothClientService.STATE_CONNECTING:
					mTitle.setText(R.string.title_connecting);
					break;
				case BluetoothClientService.STATE_LISTEN:
				case BluetoothClientService.STATE_NONE:
					mTitle.setText(R.string.title_not_connected);
					break;
				}
				break;
			case MESSAGE_WRITE:
				byte[] writeBuf = (byte[]) msg.obj;
				// construct a string from the bufferd
				String writeMessage = new String(writeBuf);
				mConversationArrayAdapter.add("Me:  " + writeMessage);
				break;
			case MESSAGE_READ:
				byte[] readBuf = (byte[]) msg.obj;
				// construct a string from the valid bytes in the buffer
				if (CommonData.valueRequested) {
					int inData = ((int) (readBuf[0] & 0xff));
					CommonData.valueRequested = false;
					count++;
					if (CommonData.vdb.opcode == 73) {
						count = 0;
						CommonData.vdb.adc[CommonData.vdb.currentChannel] = inData;
					// System.out.println("Values: "+CommonData.vdb.adc[CommonData.vdb.currentChannel]+" of curr: "+CommonData.vdb.currentChannel);
						pgAdc[CommonData.vdb.currentChannel]
								.setProgress(CommonData.vdb.adc[CommonData.vdb.currentChannel]);
						showValues[CommonData.vdb.currentChannel]
								.setText(" "
										+ CommonData.vdb.adc[CommonData.vdb.currentChannel]
										+ "/"
										+ CommonData.vdb.thr[CommonData.vdb.currentChannel]);
						paintHeartPulseECG();
						CommonData.vdb.currentChannel++;
						CommonData.vdb.uid=uid;
						if (CommonData.vdb.currentChannel == 2) {
							CommonData.vdb.currentChannel = 0;
							CommonData.vdb.opcode = 34;
						
							CommonData.vdb.Location = "Video";
							CommonData.sendToServer = true;
						}
						if (CommonData.vdb.opcode == 34) {
							//CommonData.vdb.operand = CommonData.vdb.opData;
						} else {
							CommonData.vdb.operand = CommonData.vdb.currentChannel;
						}
						
					}
				}
				break;
			case MESSAGE_DEVICE_NAME:
				// save the connected device's name
				mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
				Toast.makeText(getApplicationContext(),
						"Connected to " + mConnectedDeviceName,
						Toast.LENGTH_SHORT).show();
				byte[] b = new byte[] { 65 };
				CommonData.mChatService.write(b);
				break;
			case MESSAGE_TOAST:
				Toast.makeText(getApplicationContext(),
						msg.getData().getString(TOAST), Toast.LENGTH_SHORT)
						.show();
				break;
			}
		}
	};

	private void connectDevice(Intent data, boolean secure) {
		// Get the device MAC address
		String address = data.getExtras().getString(
				DeviceListActivity.EXTRA_DEVICE_ADDRESS);

		// Get the BLuetoothDevice object
		BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);

		// Attempt to connect to the device
		CommonData.mChatService.connect(device, secure);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (D)
			Log.d(TAG, "onActivityResult " + resultCode);
		switch (requestCode) {
		case REQUEST_CONNECT_DEVICE_INSECURE:
			// When DeviceListActivity returns with a device to connect
			if (resultCode == Activity.RESULT_OK) {
				Toast.makeText(this, "COnnecting", Toast.LENGTH_SHORT).show();
				connectDevice(data, false);
			}
			break;
		case REQUEST_ENABLE_BT:
			// When the request to enable Bluetooth returns
			if (resultCode == Activity.RESULT_OK) {
				// Bluetooth is now enabled, so set up a chat session
				setupChat();
			} else {
				// User did not enable Bluetooth or an error occured
				Log.d(TAG, "BT not enabled");
				Toast.makeText(this, R.string.bt_not_enabled_leaving,
						Toast.LENGTH_SHORT).show();
				finish();
			}
		}
	}

}
