package com.example.OwletPack;



import java.text.DateFormat;
import java.util.Date;

import com.example.OwletPack.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class MainActivity extends Activity {

	Button b;
	EditText ipAddress;
	TextView time;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		ipAddress = (EditText) findViewById(R.id.etIP);
		b = (Button) findViewById(R.id.btnProceed);
		time=(TextView) findViewById(R.id.texttime);

		
		String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date());

		// textView is the TextView view that should display it
		time.setText(currentDateTimeString);
		
		b.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
			
				Intent ii = new Intent(arg0.getContext(),
						LoginActivity.class);
				CommonData.URL = "http://" + ipAddress.getText().toString()
						+ ":8080/CityCentralServer/CityServices?wsdl";
				startActivity(ii);
				
			}
		});
	}
}
