/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPack;

import LibPack.SingleUser;
import LibPack.ValuesDB;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author OT-0018
 */
public class Settings implements Serializable{
    public static String uid="";
    
    
   
}
