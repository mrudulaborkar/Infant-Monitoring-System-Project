/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPack;

import LibPack.ValuesDB;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.taglibs.standard.tag.common.xml.SetTag;

/**
 *
 * @author OT-0018
 */
@WebServlet(name = "ReadVideo", urlPatterns = {"/ReadVideo"})
public class ReadVideo extends HttpServlet {
String connection = "jdbc:mysql://localhost/14326DB";
Connection con;
    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        System.gc();
         File f = new File("D:\\ProjectData\\14326DB\\" + Settings.uid+".dat");
        ValuesDB vdb1 = new ValuesDB();
        try {
           // System.out.println("in reading");
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(f));
            vdb1 = (ValuesDB) in.readObject();
           
            in.close();
        } catch (Exception e) {
            System.out.println("ERROR IN READING:" + e);
            e.printStackTrace();
        }

       initDatabse();
        //System.out.println("ReadDeviceDetails Service Called!");
        try {
            String qry = "SELECT * FROM devicedetails where uid='"+Settings.uid+"'";
            // System.out.println(": " + qry);
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery(qry);
            while (rs.next()) {
                for (int j = 0; j < 2; j++) {
                    vdb1.adc[j] = Integer.parseInt(rs.getString(j + 3));
                    vdb1.thr[j] = Integer.parseInt(rs.getString(j + 5));
                }
            }

            con.close();
        } catch (Exception e) {
            System.out.println("ERROR in reading : " + e);
        }

        ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
        out.writeObject(vdb1);
        out.close();
    }
 public void initDatabse() {
        try {
            //System.out.println("Database Connecting..........");
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection(connection, "root", "root");
            // System.out.println("Connection OK");
        } catch (Exception e) {
            System.out.println("Error opening database : " + e);
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
