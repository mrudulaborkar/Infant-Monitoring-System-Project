/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPack;

import LibPack.SingleUser;
import LibPack.ValuesDB;
import LibPack.Techniciondata;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Lenovo
 */
@WebService(serviceName = "CityServices")
public class CityServices {

    String connection = "jdbc:mysql://localhost/14326DB";
    String user = "root";
    String password = "root";
    Connection con;
    SingleUser fromClient;
    Statement stmt;
    ValuesDB vdb;
    SingleUser su;
    Techniciondata tdb;
    Techniciondata lg;
    static String uidreceived="";

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    String objectToString(Object obj) {
        byte[] b = null;
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutput out = new ObjectOutputStream(bos);
            out.writeObject(obj);
            b = bos.toByteArray();
        } catch (Exception e) {
            //System.out.println("NOT SERIALIZABLE: " + e);
        }
        return Base64.encode(b);
    }

    Object stringToObject(String inp) {
        byte b[] = Base64.decode(inp);
        Object ret = null;
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(b);
            ObjectInput in = new ObjectInputStream(bis);
            ret = (Object) in.readObject();
            bis.close();
            in.close();
        } catch (Exception e) {
            //System.out.println("NOT DE-SERIALIZABLE: " + e);
        }
        return ret;
    }
//
//    public void sendMessage(String msg, String to) {
//        boolean flag;
//        System.out.println("Sending SMS!!!!!!!!!!!!!!!!!!!!!!!!!! ");
//        SMSSettings sms = new SMSSettings();
//        try {
//            String pre, post, tempS;
//            pre = msg;
//            post = "";
//            for (int i = 0; i < pre.length(); i++) {
//                tempS = Integer.toHexString((int) pre.charAt(i)).toUpperCase();
//                if (tempS.length() == 1) {
//                    tempS = "0" + tempS;
//                }
//                tempS = "%" + tempS;
//                post += tempS;
//            }
//            //  System.out.println("Sms created: " + post);
//            // now sending message
//
//            String str = new String("http://india.timessms.com/http-api/receiverall.aspx?username=" + sms.userName + "&password=" + sms.pass + "&sender=" + sms.sender + "&cdmasender=&to=" + to + "&message=" + post + "");
//            //    System.out.println("STR: " + str);
//
//            URL url = new URL(str);
//            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//
//            conn.setRequestMethod("GET");
//            conn.setDoOutput(true);
//            conn.setDoInput(true);
//            conn.setUseCaches(false);
//            conn.connect();
//
//            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//            String response = "";
//            int counter = 0;
//            String temp;
//            while ((temp = br.readLine()) != null) {
//                response += temp + "\n";
//
//                // modified code... do not read more than 4 lines even in case of errors.
//                counter++;
//                if (counter > 4) {
//                    break;
//                }
//            }
//            br.close();
//            conn.disconnect();
//            // JOptionPane.showMessageDialog(null, "Gateway Response :" + response);
//        } catch (Exception e) {
//            //JOptionPane.showMessageDialog(null, "ERROR WHILE SENDING:" + e);
//            System.out.println("error sending msg:" + e);
//        }
//    }

    public void initDatabse() {
        try {
            //System.out.println("Database Connecting..........");
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection(connection, user, password);
            // System.out.println("Connection OK");
        } catch (Exception e) {
            System.out.println("Error opening database : " + e);
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "updatevideofeed")
    public String updatevideofeed(@WebParam(name = "values") String values) {
        //TODO write your implementation code here:
        System.gc();
        initDatabse();
        boolean flag=false;
        ValuesDB vdb = new ValuesDB();
        String eOut = "failed";
        // System.out.println("method Called!"+Settings.uid);
         
        try {
            vdb = (ValuesDB) stringToObject(values);
            File f = new File("D:\\ProjectData\\14326DB\\" + Settings.uid+".dat");
            if (f.exists()) {
                ObjectOutputStream oOut = new ObjectOutputStream(new FileOutputStream(f));
                oOut.writeObject(vdb);
                oOut.close();
            } else {
                ObjectOutputStream oOut = new ObjectOutputStream(new FileOutputStream("D:\\ProjectData\\14326DB\\" + Settings.uid+".dat"));
                oOut.writeObject(vdb);
                oOut.close();
            }

            eOut = "Successful";
           
        } catch (Exception e) {
            System.out.println("ERROR in video update: " + e);
            e.printStackTrace();
        }
        return eOut;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "updateDeviceData")
    public String updateDeviceData(@WebParam(name = "values") String values) {
        //TODO write your implementation code here:
        initDatabse();
        boolean flag = false;
        vdb = new ValuesDB();
        vdb = (ValuesDB) stringToObject(values);
        String eOut = "failed";
        Settings.uid=vdb.uid;
        //System.out.println("updateDeviceData Service Called!" + vdb.uid);

        try {
            String qry = "SELECT * FROM devicedetails where uid='" + vdb.uid + "'";
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery(qry);
            while (rs.next()) {
                flag = true;
            }
        } catch (Exception e) {
            System.out.println("ERROR in reading devicedetails: " + e);
        }

        try {
            if (flag) {
                String qry = "update deviceDetails set s1=" + vdb.adc[0] + ",s2=" + vdb.adc[1] + ",th1=" + vdb.thr[0] + ",th2=" + vdb.thr[1] + " where uid='" + vdb.uid + "'";
                // System.out.println(qry);
                Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                stmt.executeUpdate(qry);
                eOut = "Successful";
            } else {
                String sql = "insert into deviceDetails values(null,'" + vdb.uid + "'," +vdb.adc[0]+","+ vdb.adc[1] + "," + vdb.thr[0] + "," + vdb.thr[1] + ")"; 
                //System.out.println(sql);
                stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                stmt.executeUpdate(sql);
                eOut = "Successful";
            }
            con.close();
        } catch (Exception e) {
            System.out.println("ERROR in updating: " + e);
        }
        return eOut;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "ReadDevicedetail")
    public String ReadDevicedetail(@WebParam(name = "values") String values) {
        //TODO write your implementation code here:
        initDatabse();

        vdb = new ValuesDB();
        String resp = "";
        //System.out.println("ReadDeviceDetails Service Called!");
        try {
            String qry = "SELECT * FROM devicedetails";
            // System.out.println(": " + qry);
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery(qry);
            while (rs.next()) {
                for (int j = 0; j < 2; j++) {
                    vdb.adc[j] = Integer.parseInt(rs.getString(j + 3));
                    vdb.thr[j] = Integer.parseInt(rs.getString(j + 5));
                }
            }
            resp = objectToString(vdb);
            con.close();
        } catch (Exception e) {
            System.out.println("ERROR in reading : " + e);
        }
        return resp;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Storetechniciondata")
    public String Storetechniciondata(@WebParam(name = "values") String values) {
        //TODO write your implementation code here:
        initDatabse();
        String qry = "";
        tdb = new Techniciondata();
        tdb = (Techniciondata) stringToObject(values);

        String eOut = "failed";

        try {
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            for (int i = 0; i < 5; i++) {
                qry = "update techinfo set techtype='" + tdb.TechType[i] + "',techname='" + tdb.Techname[i] + "',Contact='" + tdb.Contact[i] + "',msg='" + tdb.msg[i] + "' where techtype='" + tdb.TechType[i] + "'";
                stmt.executeUpdate(qry);
            }

            eOut = "Successful";
            con.close();
        } catch (Exception e) {
            System.out.println("ERROR in updating tech data: " + e);
            //e.printStackTrace();
        }
        return eOut;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "SignUp")
    public String SignUp(@WebParam(name = "obj") String obj) {
        //TODO write your implementation code here:
        String resp = "NO";
        System.out.println("SIGN UP");
        su = new SingleUser();
        su = (SingleUser) stringToObject(obj);
        try {
            initDatabse();
            String sql = "insert into user values('" + su.uid + "','" + su.fname + "','" + su.mname + "','" + su.lname + "','" + su.email + "','" + su.city + "','" + su.mob + "','" + su.Gender + "','" + su.pass + "')";
            System.out.println(sql);

            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.executeUpdate(sql);

            con.close();
            resp = "YES";
        } catch (Exception e) {
            System.out.println("ERROR IN sign up from android" + e);
            e.printStackTrace();
        }
        return resp;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Android_login")
    public String Android_login(@WebParam(name = "obj") String obj) {
        //TODO write your implementation code here:
        String resp = "false";
        su = new SingleUser();
        su = (SingleUser) stringToObject(obj);
        System.out.println("uid:"+su.uid+" pass: "+su.pass);
        initDatabse();

        try {

            String sql = "select * from user where uid='" + su.uid + "' and password='" + su.pass + "'";
            System.out.println("login query: " + sql);
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                resp = "true";
            }
        } catch (Exception e) {
            System.out.println("ERROR in android Login" + e);
            e.printStackTrace();
        }
        return resp;
    }
}
